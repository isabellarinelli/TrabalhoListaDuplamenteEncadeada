package listaDE;


	public class Nodo {
   
    String Nome;
   // int codigo;
    String codigo;
    Nodo prox;
	Nodo ant; 
    
    public Nodo() {
        this.Nome=null;
       // this.codigo=000;
        this.codigo=null;
        this.prox = null;
		this.ant = null;
       
    }
    public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		this.Nome = nome;
	}
	public String getCod() {
		return codigo;
	}
	public void setCod(String cod) {
		this.codigo = cod;
	}
	public Nodo getProx() {
		return prox;
	}
	public void setProx(Nodo prox) {
		this.prox = prox;
	}
	public Nodo getAnt() {
		return ant;
	}
	public void setAnt(Nodo ant) {
		this.ant = ant;
	}
}

		
	
		
	
