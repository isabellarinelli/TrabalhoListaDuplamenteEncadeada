package listaDE;
	

import java.util.Scanner;

	class Elemento {
	    public  Nodo Nodo;
	    public Elemento Proximo;
	    public Elemento Anterior;

	    public Elemento() {
	        this.Nodo=null;
	        this.Proximo=null;
	        this.Anterior=null;
	    }

	}
	public class ListaDuplamenteEncadeada {

	    private Elemento In�cio;
	    private Elemento Fim;
	    private Elemento Aux;
	    private Elemento Anterior;
	    public int Tamanho;

	    public ListaDuplamenteEncadeada() {
	        this.In�cio =null;
	        this.Fim=null;
	        this.Tamanho = 0;

	    }

	    public void InserirNodo( Nodo N) {
	        Elemento Novo = new Elemento();
	        Novo.Nodo= N;

	        if (In�cio == null) { 
	            In�cio = Novo;
	            Fim=Novo;
	        } else { // lista nao t� vazia
	            Anterior=null;
	            Aux = In�cio;
	            while (Aux!= null && Novo.Nodo.codigo.compareTo(Aux.Nodo.codigo) >0) {
	                Anterior=Aux;
	                Aux= Aux.Proximo;
	            }
	            if (Anterior == null) { // inser��o no inicio
	                Novo.Proximo=In�cio;
	                In�cio.Anterior=Novo;
	                In�cio=Novo;
	            } else if (Aux == null) { // percorre toda a lista e n�o acha elemento maior
	                Fim.Proximo=Novo;
	                Novo.Anterior =Fim;
	                Fim=Novo;

	            } else { // inser��o no meio da lista
	              Novo.Proximo = Anterior.Proximo;
	              Novo.Proximo = Novo.Proximo.Anterior;
	              Novo.Proximo=Aux;
	            }

	        }
	        Tamanho++;

	    }

	    public void MostrarListaDE() {

	        if (In�cio == null ) {
	            System.out.println("Lista vazia!");
	            Parada();
	        } else {
	            Aux = In�cio;
	            while (Aux!=null) { // Listagem
	                System.out.printf("\n %1$2s - Nome : %2$s ", Aux.Nodo.codigo,Aux.Nodo.Nome);
	                	               
	                Aux=Aux.Proximo;

	            }
	            System.out.printf("\nN�mero de c�digos: %1$s\n\n", Tamanho);
	            Parada();
	        }
	    }

	

	    public void RemoveNodo(String cod) {
	        if (In�cio == null) {
	            System.out.println("Lista vazia!");
	            Parada();
	        } else {
	            Aux = In�cio;
	            int Existe = 0;

	            while (Aux != null) {
	                if (Aux.Nodo.codigo.equals(cod)) {
	                	Existe++;
	                    if (Aux == In�cio) { // primeiro elemento ser� excluido
	                        In�cio = Aux.Proximo;
	                        if (In�cio!= null){
	                            In�cio.Anterior =null;
	                        }
	                        Aux =In�cio;
	                        Tamanho--;
	                    } else if (Aux == Fim) { // ultimo elemento sera excluido
	                        Fim = Fim.Anterior;
	                        Fim.Proximo=null;
	                        Aux = null;

	                        Tamanho--;
	                    } else { // elemento do meio ser� excluido
	                        Aux.Anterior.Proximo = Aux.Proximo;
	                        Aux.Proximo.Anterior = Aux.Anterior;
	                        Aux = Aux.Proximo;
	                        Tamanho--;
	                    }
	                } else {
	                    Aux = Aux.Proximo;
	                }
	            }
	            if (Existe == 0) {
	                System.out.printf("O c�digo %1$s n�o existe !\n", cod);
	                Parada();
	            } else  {
	                System.out.printf("O c�digo %1$s foi encontrado e removido da lista !\n", cod);
	                Parada();
	            }
	            System.out.printf("Total de c�digos registrados -> %1$s", Tamanho);
	        }
	    }

	    public void EsvaziaLista() {
	        if (In�cio == null) {
	            System.out.println("A lista j� esta vazia ! ");
	            Parada();
	        } else {
	            In�cio = null;
	            Tamanho = 0;

	            System.out.println("Lista esvaziada com sucesso ! ");
	            System.out.printf("\nTamanho -> %1$s\n", Tamanho);
	            Parada();

	        }

	    }

	    public void VerificaNodo(String codigo) {
	        int Achou = 0;
	        if (In�cio==null) {
	            System.out.println("A lista n�o possui elementos !");
	            Parada();
	        } else {
	            Aux = In�cio;
	            while (Aux != null) {
	                if (Aux.Nodo.codigo.equals(codigo)) {
	                    Achou++;
	                }
	                Aux = Aux.Proximo;
	            }
	        }
	        if (Achou == 0 ) {
	            System.out.println("N�o existe c�digo cadastrado \n");
	            Parada();
	        } else {
	            System.out.printf("O c�digo %1$s j� est� cadastrado \n", codigo);
	            Parada();
	        }
	    }

	    private void Parada() {
	        Scanner teclado = new Scanner(System.in);

	        System.out.println("Pressione <ENTER> para continuar");
	        teclado.nextLine();
	    }


	
	

		}
	

