package listaDE;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        ListaDuplamenteEncadeada ListaCodigos = new ListaDuplamenteEncadeada();
        Scanner teclado = new Scanner(System.in);
        int op;
        do {
            
        	 System.out.println("***************************");
            System.out.println("LISTA DUPLAMENTE ENCADEADA ORDENADA");
            System.out.println("Escolha uma das op��es:");
            System.out.println("1 - Inserir um nodo");
            System.out.println("2 - Remover nodo");
            System.out.println("3 - Exibir todos os nodos");
            System.out.println("4 - Pesquisar se um c�digo existe na lista");
            System.out.println("5 - Informar o n�mero de nodos da LDE");
            System.out.println("6 - Sair");
            System.out.println("***************************");
            
            op = Integer.parseInt(teclado.nextLine());
            switch (op) {
                case 1: // Inserir nodo
                Nodo x = new  Nodo();
                    System.out.println("Nome: ");
                    x.Nome= teclado.nextLine();
                    System.out.println("C�digo: ");
                    x.codigo= teclado.nextLine();
                                                        
                    ListaCodigos.InserirNodo(x);
                    System.out.printf("\nC�digo cadastrado com sucesso !\n");
                    

                    break;
                case 2: // Remover nodo
                    String cod;
                    System.out.println("Informe o nodo para ser removido:");
                    cod = teclado.nextLine();
                    ListaCodigos.RemoveNodo(cod);
                    break;
                    
                case 3: // Mostrar a lista
                    System.out.println("***************************");
                    ListaCodigos.MostrarListaDE();
                    break;
                    
                case 4: // Pesquisa se um nodo contendo um determinado c�digo existe
                    //String cod;
                    System.out.println("***************************");
                    System.out.println("Informe o c�digo para pesquisa:");
                    cod = teclado.nextLine();
                    ListaCodigos.VerificaNodo(cod);
                    break;
                case 5: // Informar o n�mero de nodos da LDE
                	System.out.printf("N�mero de c�digos cadastrados %1$d\n", ListaCodigos.Tamanho);
                	break;
            }

        } while (op!= 6 );

    }
}

